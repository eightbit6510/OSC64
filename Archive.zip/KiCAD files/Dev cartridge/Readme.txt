Due to some design issues the Kicad files are temporarily unavailable.
Once the issues have been resolved new files will be uploaded.