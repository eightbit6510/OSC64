Version 3.7 is now available
