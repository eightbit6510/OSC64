<?php
//Sven Pook v2


$hostname = 'localhost'; 
$dbname = 'chat64';
$username = ********;  
$password = ********;
// Create connection
$conn = new mysqli($hostname, $username, $password, $dbname);
?>

